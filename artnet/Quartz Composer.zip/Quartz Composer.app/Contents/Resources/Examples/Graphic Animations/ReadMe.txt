Copyright © 2007-2009 by Apple Inc.  All Rights Reserved.

Quartz Composer Compositions

Graphic Animations				Composition examples that generate animations.

Sample Requirements				The supplied Quartz Composer compositions were created 
						using the Quartz Composer editor running under Mac OS 
						X 10.6.x or later and for compositions that use 
						OpenCL, OpenCL-capable hardware is required.

About the sample				Compositions that show how to generate animations such 
						as animated cells, cube arrays, rotating cube and so 
						on in Quartz Composer.

Using the Sample				Open the compositions using the Quartz Composer editor 
						which can be found in /Developer/Applications.

Installation					n/a

Changes from Previous Versions			n/a

Feedback and Bug Reports			Please send all feedback about this sample to:
						http://developer.apple.com/contact/feedback.html

						Please submit any bug reports about this example to 
						http://developer.apple.com/bugreport
